% Simscape(TM) Multibody(TM) version: 24.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(24).translation = [0.0 0.0 0.0];
smiData.RigidTransform(24).angle = 0.0;
smiData.RigidTransform(24).axis = [0.0 0.0 0.0];
smiData.RigidTransform(24).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [1.1453170019828585 -11.866045847590655 61.704606260017187];  % mm
% smiData.RigidTransform(1).angle = pi/2;
smiData.RigidTransform(1).angle = 0.018559157408572231;  % rad
smiData.RigidTransform(1).axis = [-2.8119795985993447e-13 1 -2.6094735015279837e-15];
smiData.RigidTransform(1).ID = "B[joint1-1:-:joint2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0.13910741634378754 -140.5341802379784 -2.2230693541730204];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962595 -0.57735026918962551 -0.57735026918962573];
smiData.RigidTransform(2).ID = "F[joint1-1:-:joint2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0.13910711936890308 6.9508460407544135 -83.723237209529316];  % mm
smiData.RigidTransform(3).angle = 3.1415916314802685;  % rad
smiData.RigidTransform(3).axis = [1 4.5827513984270975e-22 8.9672413510497367e-16];
smiData.RigidTransform(3).ID = "B[joint2-1:-:joint3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-2.9697554282392957e-07 197.73421505549328 -81.500167855356466];  % mm
smiData.RigidTransform(4).angle = 3.1415916314802605;  % rad
smiData.RigidTransform(4).axis = [1 -6.6303165628222121e-22 -1.2973788718483745e-15];
smiData.RigidTransform(4).ID = "F[joint2-1:-:joint3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-2.969748722492227e-07 447.73419248582684 -103.5904233827265];  % mm
smiData.RigidTransform(5).angle = 1.0221095252775571e-06;  % rad
smiData.RigidTransform(5).axis = [-1 -1.7379319881768253e-09 8.8817841970012523e-16];
smiData.RigidTransform(5).ID = "B[joint3-1:-:joint4-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [9.0949470177292824e-13 447.8341848200198 -111.09042338276168];  % mm
smiData.RigidTransform(6).angle = 1.0221095557338356e-06;  % rad
smiData.RigidTransform(6).axis = [-1 -7.0738697195765287e-09 3.6151349181980144e-15];
smiData.RigidTransform(6).ID = "F[joint3-1:-:joint4-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [1.1254996934439987e-11 697.83432111987986 22.260966007635744];  % mm
smiData.RigidTransform(7).angle = 3.1415916314802601;  % rad
smiData.RigidTransform(7).axis = [1 5.1064629176439009e-22 9.9920072216264049e-16];
smiData.RigidTransform(7).ID = "B[joint4-1:-:joint5-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [1.0786038728838321e-11 697.83432060882433 21.760966007654019];  % mm
smiData.RigidTransform(8).angle = 3.1415916314802597;  % rad
smiData.RigidTransform(8).axis = [1 -6.888680209396724e-21 -1.3479338533107459e-14];
smiData.RigidTransform(8).ID = "F[joint4-1:-:joint5-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [1.6426758579576511e-11 673.07254152721657 -109.50065360103061];  % mm
smiData.RigidTransform(9).angle = 2.0943956925085101;  % rad
smiData.RigidTransform(9).axis = [-0.5773504658945966 -0.5773504658945966 -0.57734987577948305];
smiData.RigidTransform(9).ID = "B[joint5-2:-:joint6-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-2.969618744241842e-07 673.47254122056586 -109.8006541120526];  % mm
smiData.RigidTransform(10).angle = 2.0943956925085043;  % rad
smiData.RigidTransform(10).axis = [-0.5773504658945946 -0.5773504658945946 -0.57734987577948704];
smiData.RigidTransform(10).ID = "F[joint5-2:-:joint6-2]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-2.9697500014691514e-07 105.280803858979 -32.490073357818979];  % mm
smiData.RigidTransform(11).angle = 1.5707963267951597;  % rad
smiData.RigidTransform(11).axis = [-5.1105476256897911e-07 -0.99999999999973888 5.1105476256897911e-07];
smiData.RigidTransform(11).ID = "AssemblyGround[joint3-1:joint3.step-1:J3_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [0 0 0];  % mm
smiData.RigidTransform(12).angle = 0;  % rad
smiData.RigidTransform(12).axis = [0 0 0];
smiData.RigidTransform(12).ID = "AssemblyGround[joint3-1:joint3.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0 356.88057993245411 -88.560330418195008];  % mm
smiData.RigidTransform(13).angle = 1.5707963267951559;  % rad
smiData.RigidTransform(13).axis = [-5.1105476651280771e-07 0.99999999999973888 -5.1105476651280771e-07];
smiData.RigidTransform(13).ID = "AssemblyGround[joint4-1:joint4.step-1:J4_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [0 0 0];  % mm
smiData.RigidTransform(14).angle = 0;  % rad
smiData.RigidTransform(14).axis = [0 0 0];
smiData.RigidTransform(14).ID = "AssemblyGround[joint4-1:joint4.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [0.22021117051999883 -11.866045847591003 11.864002322045];  % mm
smiData.RigidTransform(15).angle = 1.5707963267949006;  % rad
smiData.RigidTransform(15).axis = [0.99982778378143999 -3.0409702533873428e-15 -0.018558092000370958];
smiData.RigidTransform(15).ID = "AssemblyGround[joint1-1:joint1.step-1:joint1.step.step-1:J1_X_B2_X_BF_X_B7_X_D6-W.step.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [0 0 0];  % mm
smiData.RigidTransform(16).angle = 0;  % rad
smiData.RigidTransform(16).axis = [0 0 0];
smiData.RigidTransform(16).ID = "AssemblyGround[joint1-1:joint1.step-1:joint1.step.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [0 0 0];  % mm
smiData.RigidTransform(17).angle = 0;  % rad
smiData.RigidTransform(17).axis = [0 0 0];
smiData.RigidTransform(17).ID = "AssemblyGround[joint1-1:joint1.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [0.13910741633595125 -42.9182813782 -154.66849366868601];  % mm
smiData.RigidTransform(18).angle = 0;  % rad
smiData.RigidTransform(18).axis = [0 0 0];
smiData.RigidTransform(18).ID = "AssemblyGround[joint2-1:joint2.step-1:J2_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 0 0];  % mm
smiData.RigidTransform(19).angle = 0;  % rad
smiData.RigidTransform(19).axis = [0 0 0];
smiData.RigidTransform(19).ID = "AssemblyGround[joint2-1:joint2.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-3.2841688923923584e-05 804.73418613834019 -109.80078827582999];  % mm
smiData.RigidTransform(20).angle = 1.5707963267951559;  % rad
smiData.RigidTransform(20).axis = [-5.1105476149985508e-07 0.99999999999973888 -5.1105476150015323e-07];
smiData.RigidTransform(20).ID = "AssemblyGround[joint6-2:joint6.step-1:J6_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [0 0 0];  % mm
smiData.RigidTransform(21).angle = 0;  % rad
smiData.RigidTransform(21).axis = [0 0 0];
smiData.RigidTransform(21).ID = "AssemblyGround[joint6-2:joint6.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [1.1990408665951691e-11 -1.5051340404800273 -56.499964108722985];  % mm
smiData.RigidTransform(22).angle = 1.0221095330060979e-06;  % rad
smiData.RigidTransform(22).axis = [-1 -1.9655875318503869e-09 0];
smiData.RigidTransform(22).ID = "AssemblyGround[joint5-2:joint5.step-1:J5_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [0 0 0];  % mm
smiData.RigidTransform(23).angle = 0;  % rad
smiData.RigidTransform(23).axis = [0 0 0];
smiData.RigidTransform(23).ID = "AssemblyGround[joint5-2:joint5.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [81.495057751277415 77.273510375507925 76.517553589497396];  % mm
smiData.RigidTransform(24).angle = 0;  % rad
smiData.RigidTransform(24).axis = [0 0 0];
smiData.RigidTransform(24).ID = "RootGround[joint1-1]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(6).mass = 0.0;
smiData.Solid(6).CoM = [0.0 0.0 0.0];
smiData.Solid(6).MoI = [0.0 0.0 0.0];
smiData.Solid(6).PoI = [0.0 0.0 0.0];
smiData.Solid(6).color = [0.0 0.0 0.0];
smiData.Solid(6).opacity = 0.0;
smiData.Solid(6).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.46592480530501063;  % kg
smiData.Solid(1).CoM = [-86.744786571347419 217.45689671541217 0.0013095683856403522];  % mm
smiData.Solid(1).MoI = [3396.958310151862 294.08916878573046 3321.3373638051785];  % kg*mm^2
smiData.Solid(1).PoI = [-0.066400758610039454 -0.0037996136735989959 0.14240196290422333];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "J3_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.60890245045283387;  % kg
smiData.Solid(2).CoM = [-73.35628465754499 218.69692171779926 -0.19952213855300477];  % mm
smiData.Solid(2).MoI = [4461.9903954845704 475.86759643663908 4528.5864262110208];  % kg*mm^2
smiData.Solid(2).PoI = [14.958788193599316 0.65293834467212075 -13.7469929155559];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "J4_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.67313749982741033;  % kg
smiData.Solid(3).CoM = [-6.8655122611758674 68.195579262738264 -0.22058402198452107];  % mm
smiData.Solid(3).MoI = [2072.9568560892612 1283.5155137814932 2284.2755358322565];  % kg*mm^2
smiData.Solid(3).PoI = [-4.1730878700821856 -6.4517765594931529 -155.00541618602557];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "J1_X_B2_X_BF_X_B7_X_D6-W.step.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.23131779645055436;  % kg
smiData.Solid(4).CoM = [0.00064936811678871487 42.662823773027363 121.1290648574255];  % mm
smiData.Solid(4).MoI = [351.08344718541935 332.71315014386516 227.65076207177219];  % kg*mm^2
smiData.Solid(4).PoI = [53.637663375816551 0.0024925414338946533 -0.0028514955984109613];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "J2_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.20912291067533101;  % kg
smiData.Solid(5).CoM = [20.503046438799938 -2.3294712461368325 -0.10488027869170119];  % mm
smiData.Solid(5).MoI = [147.98007382040376 304.27768239572481 318.58819102013462];  % kg*mm^2
smiData.Solid(5).PoI = [-0.018615735583242508 0.10904231490395234 -6.0799512120835164];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "J6_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.14243587243242448;  % kg
smiData.Solid(6).CoM = [0.46029362430361154 718.63465444961798 -49.469878343469105];  % mm
smiData.Solid(6).MoI = [117.52794075741942 96.178212369481656 105.35386223366574];  % kg*mm^2
smiData.Solid(6).PoI = [10.865416228939019 0.1299084481409491 -0.81215317580742152];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = "J5_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(5).Rz.Pos = 0.0;
smiData.RevoluteJoint(5).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -90.0;  % deg
smiData.RevoluteJoint(1).ID = "[joint1-1:-:joint2-1]";

smiData.RevoluteJoint(2).Rz.Pos = 90.0;  % deg
smiData.RevoluteJoint(2).ID = "[joint2-1:-:joint3-1]";

smiData.RevoluteJoint(3).Rz.Pos = 0.0;  % deg
smiData.RevoluteJoint(3).ID = "[joint3-1:-:joint4-1]";

smiData.RevoluteJoint(4).Rz.Pos = 90.0;  % deg
smiData.RevoluteJoint(4).ID = "[joint4-1:-:joint5-2]";

smiData.RevoluteJoint(5).Rz.Pos = 0.0;  % deg
smiData.RevoluteJoint(5).ID = "[joint5-2:-:joint6-2]";

