% Simscape(TM) Multibody(TM) version: 24.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(24).translation = [0.0 0.0 0.0];
smiData.RigidTransform(24).angle = 0.0;
smiData.RigidTransform(24).axis = [0.0 0.0 0.0];
smiData.RigidTransform(24).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [1.1453170019828585 -11.866045847590655 61.704606260017187];  % mm
smiData.RigidTransform(1).angle = 0.018559157408572231;  % rad
smiData.RigidTransform(1).axis = [-2.8119795985993447e-13 1 -2.6094735015279837e-15];
smiData.RigidTransform(1).ID = "B[joint1-1:-:joint2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0.13910741634366097 -140.53418023797838 -2.2230693541730204];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931966;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962606 -0.57735026918962518 -0.57735026918962595];
smiData.RigidTransform(2).ID = "F[joint1-1:-:joint2-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0.13910711936897246 6.9508460407544135 -83.723237209529287];  % mm
smiData.RigidTransform(3).angle = 3.1415916314802685;  % rad
smiData.RigidTransform(3).axis = [1 6.2930221947843818e-22 1.2313792292686226e-15];
smiData.RigidTransform(3).ID = "B[joint2-1:-:joint3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-2.9697483228119381e-07 197.73421505549368 -81.500167855357319];  % mm
smiData.RigidTransform(4).angle = 3.1415916314802659;  % rad
smiData.RigidTransform(4).axis = [1 6.2770627288105031e-22 1.2282563776107735e-15];
smiData.RigidTransform(4).ID = "F[joint2-1:-:joint3-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-2.9697487091695507e-07 447.73419248582695 -103.5904233827265];  % mm
smiData.RigidTransform(5).angle = 1.0221095249993459e-06;  % rad
smiData.RigidTransform(5).axis = [-1 -1.9551734872311126e-09 9.9920072216264089e-16];
smiData.RigidTransform(5).ID = "B[joint3-1:-:joint4-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-5.6843418860808015e-14 447.83418482002293 -111.09042338275395];  % mm
smiData.RigidTransform(6).angle = 1.022109535298661e-06;  % rad
smiData.RigidTransform(6).axis = [-1 -3.3139694721263362e-09 1.693619898574647e-15];
smiData.RigidTransform(6).ID = "F[joint3-1:-:joint4-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [1.1084466677857563e-11 697.83432111987963 22.260966007635744];  % mm
smiData.RigidTransform(7).angle = 3.1415916314802601;  % rad
smiData.RigidTransform(7).axis = [1 5.6738476861099142e-22 1.1102230246251561e-15];
smiData.RigidTransform(7).ID = "B[joint4-1:-:joint5-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [1.1709744285326451e-11 697.83431958671611 20.760966007637762];  % mm
smiData.RigidTransform(8).angle = 3.1415916314802605;  % rad
smiData.RigidTransform(8).axis = [1 1.1304465516041274e-22 2.2119871017829983e-16];
smiData.RigidTransform(8).ID = "F[joint4-1:-:joint5-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [1.6426309353470144e-11 673.07254152721646 -109.50065360103068];  % mm
smiData.RigidTransform(9).angle = 2.0943956925085101;  % rad
smiData.RigidTransform(9).axis = [-0.5773504658945966 -0.5773504658945966 -0.57734987577948305];
smiData.RigidTransform(9).ID = "B[joint5-1:-:joint6-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-2.9695922876271652e-07 673.47254122056654 -109.80065411205294];  % mm
smiData.RigidTransform(10).angle = 2.0943956925085052;  % rad
smiData.RigidTransform(10).axis = [-0.57735046589459504 -0.5773504658945956 -0.5773498757794856];
smiData.RigidTransform(10).ID = "F[joint5-1:-:joint6-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [0 356.88057993245405 -88.56033041819498];  % mm
smiData.RigidTransform(11).angle = 1.5707963267951555;  % rad
smiData.RigidTransform(11).axis = [-5.1105476649829836e-07 0.99999999999973888 -5.1105476649829836e-07];
smiData.RigidTransform(11).ID = "AssemblyGround[joint4-1:joint4.step-1:J4_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [0 0 0];  % mm
smiData.RigidTransform(12).angle = 0;  % rad
smiData.RigidTransform(12).axis = [0 0 0];
smiData.RigidTransform(12).ID = "AssemblyGround[joint4-1:joint4.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0.1391074163360484 -42.9182813782 -154.66849366868604];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = "AssemblyGround[joint2-1:joint2.step-1:J2_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [0 0 0];  % mm
smiData.RigidTransform(14).angle = 0;  % rad
smiData.RigidTransform(14).axis = [0 0 0];
smiData.RigidTransform(14).ID = "AssemblyGround[joint2-1:joint2.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [0.22021117051999883 -11.866045847591003 11.864002322045];  % mm
smiData.RigidTransform(15).angle = 1.5707963267949006;  % rad
smiData.RigidTransform(15).axis = [0.99982778378143999 -3.0409702533873428e-15 -0.018558092000370958];
smiData.RigidTransform(15).ID = "AssemblyGround[joint1-1:joint1.step-1:joint1.step.step-1:J1_X_B2_X_BF_X_B7_X_D6-W.step.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [0 0 0];  % mm
smiData.RigidTransform(16).angle = 0;  % rad
smiData.RigidTransform(16).axis = [0 0 0];
smiData.RigidTransform(16).ID = "AssemblyGround[joint1-1:joint1.step-1:joint1.step.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [0 0 0];  % mm
smiData.RigidTransform(17).angle = 0;  % rad
smiData.RigidTransform(17).axis = [0 0 0];
smiData.RigidTransform(17).ID = "AssemblyGround[joint1-1:joint1.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-2.9697505565806637e-07 105.280803858979 -32.490073357819007];  % mm
smiData.RigidTransform(18).angle = 1.5707963267951599;  % rad
smiData.RigidTransform(18).axis = [-5.1105476252349016e-07 -0.99999999999973888 5.1105476247567674e-07];
smiData.RigidTransform(18).ID = "AssemblyGround[joint3-1:joint3.step-1:J3_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 0 0];  % mm
smiData.RigidTransform(19).angle = 0;  % rad
smiData.RigidTransform(19).axis = [0 0 0];
smiData.RigidTransform(19).ID = "AssemblyGround[joint3-1:joint3.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [1.1934897514720433e-11 -1.5051340404800135 -56.499964108723006];  % mm
smiData.RigidTransform(20).angle = 1.0221095330071416e-06;  % rad
smiData.RigidTransform(20).axis = [-1 -1.9572949674366702e-09 0];
smiData.RigidTransform(20).ID = "AssemblyGround[joint5-1:joint5.step-1:J5_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [0 0 0];  % mm
smiData.RigidTransform(21).angle = 0;  % rad
smiData.RigidTransform(21).axis = [0 0 0];
smiData.RigidTransform(21).ID = "AssemblyGround[joint5-1:joint5.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-3.2841688965556948e-05 804.73418613834019 -109.80078827583];  % mm
smiData.RigidTransform(22).angle = 1.5707963267951555;  % rad
smiData.RigidTransform(22).axis = [-5.1105476147998707e-07 0.99999999999973888 -5.1105476147998718e-07];
smiData.RigidTransform(22).ID = "AssemblyGround[joint6-1:joint6.step-1:J6_X_B2_X_BF_X_B7_X_D6-W.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [0 0 0];  % mm
smiData.RigidTransform(23).angle = 0;  % rad
smiData.RigidTransform(23).axis = [0 0 0];
smiData.RigidTransform(23).ID = "AssemblyGround[joint6-1:joint6.step-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [81.495057751277415 77.273510375507925 76.517553589497396];  % mm
smiData.RigidTransform(24).angle = 0;  % rad
smiData.RigidTransform(24).axis = [0 0 0];
smiData.RigidTransform(24).ID = "RootGround[joint1-1]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(6).mass = 0.0;
smiData.Solid(6).CoM = [0.0 0.0 0.0];
smiData.Solid(6).MoI = [0.0 0.0 0.0];
smiData.Solid(6).PoI = [0.0 0.0 0.0];
smiData.Solid(6).color = [0.0 0.0 0.0];
smiData.Solid(6).opacity = 0.0;
smiData.Solid(6).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.60890245044776525;  % kg
smiData.Solid(1).CoM = [-73.356284657397751 218.69692171718071 -0.19952213864127941];  % mm
smiData.Solid(1).MoI = [4461.990395440519 475.86759643387734 4528.5864261662464];  % kg*mm^2
smiData.Solid(1).PoI = [14.958788198979578 0.6529383438909605 -13.746992920886706];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "J4_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.23131779645055428;  % kg
smiData.Solid(2).CoM = [0.00064936811679054598 42.662823773027355 121.12906485742549];  % mm
smiData.Solid(2).MoI = [351.08344718541917 332.71315014386505 227.65076207177214];  % kg*mm^2
smiData.Solid(2).PoI = [53.637663375816622 0.0024925414338723808 -0.0028514955984188161];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "J2_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.67313749982895787;  % kg
smiData.Solid(3).CoM = [-6.8655122613146489 68.195579262630858 -0.22058402206776512];  % mm
smiData.Solid(3).MoI = [2072.9568560945022 1283.515513788602 2284.2755358408417];  % kg*mm^2
smiData.Solid(3).PoI = [-4.1730878722157305 -6.4517765620485008 -155.00541619047209];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "J1_X_B2_X_BF_X_B7_X_D6-W.step.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.46592480530534358;  % kg
smiData.Solid(4).CoM = [-86.744786571336547 217.45689671541217 0.0013095683823518393];  % mm
smiData.Solid(4).MoI = [3396.958310153308 294.08916878581852 3321.3373638066978];  % kg*mm^2
smiData.Solid(4).PoI = [-0.066400758610053331 -0.0037996136489208835 0.14240196290425453];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "J3_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.14243586959399845;  % kg
smiData.Solid(5).CoM = [0.4602932478927983 718.63465499494669 -49.469878857317156];  % mm
smiData.Solid(5).MoI = [117.5279366653985 96.178209320511485 105.35385902275971];  % kg*mm^2
smiData.Solid(5).PoI = [10.865414223432699 0.12990990364504162 -0.81215464358591638];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "J5_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.20912291067533098;  % kg
smiData.Solid(6).CoM = [20.503046438799942 -2.3294712461368325 -0.1048802786917009];  % mm
smiData.Solid(6).MoI = [147.98007382040478 304.2776823957247 318.58819102013564];  % kg*mm^2
smiData.Solid(6).PoI = [-0.0186157355832515 0.10904231490395817 -6.0799512120834969];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = "J6_X_B2_X_BF_X_B7_X_D6-W.step*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(5).Rz.Pos = 0.0;
smiData.RevoluteJoint(5).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -98.274503201400591;  % deg
smiData.RevoluteJoint(1).ID = "[joint1-1:-:joint2-1]";

smiData.RevoluteJoint(2).Rz.Pos = 85.022793693868394;  % deg
smiData.RevoluteJoint(2).ID = "[joint2-1:-:joint3-1]";

smiData.RevoluteJoint(3).Rz.Pos = -11.597430885023883;  % deg
smiData.RevoluteJoint(3).ID = "[joint3-1:-:joint4-1]";

smiData.RevoluteJoint(4).Rz.Pos = -9.4875832011621561;  % deg
smiData.RevoluteJoint(4).ID = "[joint4-1:-:joint5-1]";

smiData.RevoluteJoint(5).Rz.Pos = -106.84581311556316;  % deg
smiData.RevoluteJoint(5).ID = "[joint5-1:-:joint6-1]";

